import RoleCard from "./RoleCard";

export default function LoginSection() {
  return (
    <div className="md:w-1/2 flex items-center justify-center p-10">
      <div className="w-full max-w-sm space-y-8">
        <RoleCard
          role="Student"
          primaryColor="indigo"
          loginLink="/student/login"
          registerLink="/student/register"
        />
        <RoleCard
          role="Professor"
          primaryColor="blue"
          loginLink="/professor/login"
          registerLink="/professor/register"
        />
      </div>
    </div>
  );
}
