export default function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-5 text-center text-3xl font-extrabold shadow">
      ProfConnect
    </header>
  );
}
