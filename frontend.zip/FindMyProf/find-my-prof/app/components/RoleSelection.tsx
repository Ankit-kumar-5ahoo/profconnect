import RoleCard from "./RoleCard";

export default function RoleSelection() {
  return (
    <div className="md:w-1/2 flex items-center justify-center p-10">
      <div className="w-full max-w-sm space-y-8">
        {/* Student card */}
        <RoleCard
          role="Student"
          color="indigo"
          loginLink="/student/login"
          registerLink="/student/register"
        />

        {/* Professor card */}
        <RoleCard
          role="Professor"
          color="blue"
          loginLink="/professor/login"
          registerLink="/professor/register"
        />
      </div>
    </div>
  );
}
