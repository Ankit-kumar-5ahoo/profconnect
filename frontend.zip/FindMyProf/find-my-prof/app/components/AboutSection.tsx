export default function AboutSection() {
  return (
    <div className="md:w-1/2 flex items-center justify-center p-10 bg-white">
      <div className="max-w-md">
        <h1 className="text-4xl font-bold text-blue-700 mb-4">Connect. Learn. Grow.</h1>
        <p className="text-gray-700 leading-relaxed mb-4">
          <strong>ProfConnect</strong> bridges the gap between professors and students across institutes.
          Professors can post opportunities such as research projects, internships, and assistantships.
        </p>
        <p className="text-gray-700 leading-relaxed">
          Students can browse, apply, and even get course recommendations based on required prerequisites.
          Secure institute ID verification ensures trusted access for all users.
        </p>
      </div>
    </div>
  );
}
