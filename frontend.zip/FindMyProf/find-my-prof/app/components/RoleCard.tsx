interface RoleCardProps {
  role: "Student" | "Professor";
  color: string;
  loginLink: string;
  registerLink: string;
}

export default function RoleCard({ role, color, loginLink, registerLink }: RoleCardProps) {
  const bgColor = color === "blue" ? "bg-blue-600 hover:bg-blue-700" : "bg-indigo-600 hover:bg-indigo-700";
  const textColor = color === "blue" ? "text-blue-700" : "text-indigo-700";
  const linkColor = color === "blue" ? "text-blue-600" : "text-indigo-600";

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition">
      <h2 className={`text-2xl font-semibold mb-4 ${textColor} text-center`}>{role}</h2>

      <a href={loginLink} className={`block ${bgColor} text-white rounded-lg px-4 py-2 mb-3 text-center transition`}>
        Login
      </a>

      <a
        href={registerLink}
        className="block bg-gray-100 hover:bg-gray-200 text-black hover:text-gray-800 rounded-lg px-4 py-2 text-center transition"
      >
        Register
      </a>

      <p className="text-sm text-gray-500 mt-2 text-center">Register if you are a first-time user</p>
      <a href="#" className={`block text-sm ${linkColor} hover:underline text-center mt-2`}>
        Forgot Password?
      </a>
    </div>
  );
}
