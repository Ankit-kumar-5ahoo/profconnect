import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { email, otp } = await req.json();

  const store = globalThis.otpStore;

  if (!store) {
    return NextResponse.json({ success: false, message: "OTP not generated" });
  }

  if (store.email !== email) {
    return NextResponse.json({ success: false, message: "Invalid email" });
  }

  if (Date.now() > store.expires) {
    return NextResponse.json({ success: false, message: "OTP expired" });
  }

  if (store.otp !== otp) {
    return NextResponse.json({ success: false, message: "Incorrect OTP" });
  }

  return NextResponse.json({ success: true, message: "OTP verified" });
};