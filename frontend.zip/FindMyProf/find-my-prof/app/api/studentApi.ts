import { API_BASE_URL } from "@/config/api";

export async function registerStudent(payload: {
  name: string;
  email: string;
  department: string;
  year: string;
  password: string;
}) {
  const response = await fetch(`${API_BASE_URL}/api/students/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  return { ok: response.ok, data };
}
