import { API_BASE_URL } from "@/config/api";

export async function loginUser(
  endpoint: string,
  payload: { email: string; password: string }
) {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  return { ok: response.ok, data };
}
