import { NextResponse } from "next/server";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: Request) {
  const { email } = await req.json();

  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  globalThis.otpStore = {
    email,
    otp,
    expires: Date.now() + 5 * 60 * 1000,
  };

  try {
    await resend.emails.send({
      from: process.env.MAIL_FROM || "onboarding@resend.dev",
      to: email,
      subject: "Your OTP Code",
      html: `<p>Your OTP is <strong>${otp}</strong></p>`,
    });

    return NextResponse.json({ success: true, message: "OTP sent" });
  } catch (error) {
    console.error(error);
    return NextResponse.json({
      success: false,
      message: "Failed to send email",
    });
  }
}
