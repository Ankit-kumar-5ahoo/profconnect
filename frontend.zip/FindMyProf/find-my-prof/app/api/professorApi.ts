import { API_BASE_URL } from "@/config/api";

export async function registerProfessor(payload: {
  name: string;
  department: string;
  email: string;
  bio: string;
  password: string;
  specialization: string;
}) {
  const response = await fetch(`${API_BASE_URL}/api/professors/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  return { ok: response.ok, data };
}
