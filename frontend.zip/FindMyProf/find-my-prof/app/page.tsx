// Main Landing Page
import Header from "./components/Header";
import AboutSection from "./components/AboutSection";
import RoleSelection from "./components/RoleSelection"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-r from-white to-[#eef4ff]">
      <Header />

      <main className="flex flex-1 flex-col md:flex-row">
        <AboutSection />
        <RoleSelection />
      </main>
    </div>
  );
}
