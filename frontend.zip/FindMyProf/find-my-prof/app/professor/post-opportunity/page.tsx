"use client";

import { useState, useRef  } from "react";

export default function PostOpportunity() {
  const formRef = useRef<HTMLFormElement>(null);
  const [type, setType] = useState("");
  const [showOther, setShowOther] = useState(false);
  const [pdfFile, setPdfFile] = useState<File | null>(null);

  // Success modal
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  const [form, setForm] = useState({
    title: "",
    description: "",
    fieldOfStudy: "",
    duration: "",
    prerequisites: "",
    type: "",
    otherType: "",
    institute: "",
    professorName: "",
  });

  const handleChange = (e: any) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setType(value);
    setShowOther(value === "Other");
    setForm({ ...form, type: value });
  };

  // Convert file → base64
  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(",")[1]); // Return only base64 part
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });

  // -------------------------
  // ON SUBMIT
  // -------------------------
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!pdfFile) {
      alert("Please upload the PDF file");
      return;
    }

    // Validate PDF type
    if (pdfFile.type !== "application/pdf") {
      alert("Only PDF files are allowed");
      return;
    }

    // Validate < 300 KB
    const MAX_SIZE = 300 * 1024;
    if (pdfFile.size > MAX_SIZE) {
      alert("PDF size must be below 300 KB");
      return;
    }

    // Convert PDF → Base64
    const pdfBase64 = await fileToBase64(pdfFile);

    // -----------------------------------------
    // Save the Opportunity into localStorage
    // -----------------------------------------
    const stored = localStorage.getItem("opportunities");
    const opportunities = stored ? JSON.parse(stored) : [];

    // Get professorId from login token (ex: "prof_5")
    const token = sessionStorage.getItem("professor_token");
    const professorId = token ? Number(token.split("_")[1]) : 1;

    const newOpportunity = {
      id: Date.now(),
      title: form.title,
      description: form.description,
      professor: sessionStorage.getItem("professor_name") || "",
      professorId,
      professorEmail: sessionStorage.getItem("professor_email") || "",
      institute: form.institute,
      field: form.fieldOfStudy,
      type: form.type === "Other" ? form.otherType : form.type,
      duration: form.duration,
      prerequisites: form.prerequisites,
      pdfBase64,
      pdfName: pdfFile.name,
      createdAt: Date.now(),
    };

    opportunities.push(newOpportunity);
    localStorage.setItem("opportunities", JSON.stringify(opportunities));

    // Show success modal
    setSuccessMsg("Opportunity posted successfully!");
    setShowSuccessModal(true);

    // Reset form
    formRef.current?.reset();
    setType("");
    setShowOther(false);
    setPdfFile(null);
  };

  return (
    <div className="bg-gray-50 min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white text-center py-4 shadow-md">
        <h1 className="text-2xl font-bold">ProfConnect - Post Opportunity</h1>
      </header>

      {/* Form */}
      <main className="flex-grow flex items-center justify-center p-6">
        <form
          onSubmit={handleSubmit}
          className="bg-white shadow-lg rounded-2xl p-8 w-full max-w-lg space-y-5"
        >
          {/* Title */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Opportunity Title
            </label>
            <input
              name="title"
              type="text"
              placeholder="Enter title"
              required
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Description
            </label>
            <input
              name="description"
              type="text"
              placeholder="Short description"
              required
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          {/* Institute */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Institute Name
            </label>
            <input
              name="institute"
              type="text"
              placeholder="e.g. IIT Delhi"
              required
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          {/* Field of Study */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Field of Study
            </label>
            <input
              name="fieldOfStudy"
              type="text"
              placeholder="e.g. AI/ML"
              required
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          {/* Type */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Type of Opportunity
            </label>
            <select
              value={type}
              onChange={handleTypeChange}
              className="w-full border rounded-lg px-3 py-2"
            >
              <option value="">Select</option>
              <option value="RA">Research Assistantship (RA)</option>
              <option value="TA">Teaching Assistantship (TA)</option>
              <option value="Internship">Internship</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {showOther && (
            <div>
              <label className="block font-medium mb-1 text-gray-700">
                Please Specify
              </label>
              <input
                name="otherType"
                type="text"
                placeholder="Enter type"
                onChange={handleChange}
                className="w-full border rounded-lg px-3 py-2"
              />
            </div>
          )}

          {/* Duration */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Duration
            </label>
            <input
              name="duration"
              type="text"
              placeholder="e.g. 3 months"
              required
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>

          {/* Pre-requisites */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Pre-requisites
            </label>
            <textarea
              name="prerequisites"
              placeholder="List required skills/courses"
              rows={3}
              required
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            ></textarea>
          </div>

          {/* File upload */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Upload Detailed PDF
            </label>

            <input
              type="file"
              accept="application/pdf"
              onChange={(e) => setPdfFile(e.target.files?.[0] || null)}
              className="w-full border rounded-lg px-3 py-2 cursor-pointer
                         file:border file:border-gray-400 file:px-3 file:py-1"
            />

            <p className="text-xs text-gray-500 mt-1">
              * Only PDF allowed (Max size: 300 KB)
            </p>
          </div>

          {/* Submit */}
          <div className="text-center">
            <button
              type="submit"
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition"
            >
              Post Opportunity
            </button>
          </div>
        </form>
      </main>

      {/* SUCCESS MODAL */}
      {showSuccessModal && (
        <div className="fixed inset-0 flex items-center justify-center backdrop-blur-md bg-black/30 z-[9999]">
          <div className="bg-white rounded-2xl p-6 w-[90%] max-w-md text-center shadow-xl">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-green-600 text-4xl">✔</span>
            </div>

            <h3 className="text-xl font-semibold mb-2 text-gray-800">
              Success
            </h3>

            <p className="text-gray-600 mb-6">{successMsg}</p>

            <button
              onClick={() => {
                setShowSuccessModal(false);
                window.location.href = "/professor/dashboard";
              }}
              className="px-5 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
