"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";

export default function Register() {
  const router = useRouter();

  // ---------------------
  // FORM STATE
  // ---------------------
  const [form, setForm] = useState({
    name: "",
    department: "",
    bio: "",
    specialization: "",
    password: "",
    email: "",
    otp: "",
  });

  // ---------------------
  // UI STATES
  // ---------------------
  const [otpSent, setOtpSent] = useState(false);
  const [sendLoading, setSendLoading] = useState(false);
  const [verifyLoading, setVerifyLoading] = useState(false);

  // ---------------------
  // ALERT STATE
  // ---------------------
  const [alert, setAlert] = useState({
    type: "",
    message: "",
    show: false,
  });

  const showAlert = (type: string, message: string | undefined) => {
    setAlert({ type, message: message ?? "", show: true });

    setTimeout(() => {
      setAlert({ type: "", message: "", show: false });
    }, 3000);
  };

  // ---------------------
  // SUCCESS MODAL
  // ---------------------
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // ---------------------
  // HANDLERS
  // ---------------------
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Save to localStorage
  const saveProfessorToLocal = (prof: any) => {
    const existing = JSON.parse(localStorage.getItem("professors") || "[]");

    if (existing.some((p: any) => p.email === prof.email)) {
      return { ok: false, message: "Email already registered!" };
    }

    existing.push({ id: Date.now(), ...prof });
    localStorage.setItem("professors", JSON.stringify(existing));

    return { ok: true };
  };

  // SEND OTP
  const sendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setSendLoading(true);

    try {
      await fetch("/api/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email }),
      });

      setOtpSent(true);
      showAlert("success", "OTP sent to your email!");
    } catch (error) {
      showAlert("error", "Failed to send OTP");
    }

    setSendLoading(false);
  };

  // VERIFY OTP + REGISTER
  const verifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifyLoading(true);

    try {
      const res = await fetch("/api/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email, otp: form.otp }),
      });

      const data = await res.json();

      if (!data.success) {
        showAlert("error", "Invalid OTP");
        setVerifyLoading(false);
        return;
      }

      const result = saveProfessorToLocal({
        name: form.name,
        department: form.department,
        email: form.email,
        bio: form.bio,
        password: form.password,
        specialization: form.specialization,
      });

      if (!result.ok) {
        showAlert("warning", result.message);
        setVerifyLoading(false);
        return;
      }

      setShowSuccessModal(true);
    } catch (error) {
      showAlert("error", "Something went wrong");
    }

    setVerifyLoading(false);
  };

  return (
    <div className="bg-gradient-to-r from-indigo-50 to-blue-50 min-h-screen flex flex-col">
      <header className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white text-center py-4 shadow-md">
        <h1 className="text-2xl font-bold">ProfConnect - First Time Registration</h1>
      </header>

      <main className="flex-grow flex items-center justify-center p-6 relative">

        {/* ALERT BOX */}
        <div className="absolute top-20 w-full max-w-md mx-auto">
          {alert.show && (
            <div
              className={`p-3 rounded-lg flex items-center gap-2 text-white shadow-md animate-fadeIn
                ${
                  alert.type === "success"
                    ? "bg-green-600"
                    : alert.type === "error"
                    ? "bg-red-600"
                    : "bg-yellow-500"
                }
              `}
            >
              {alert.type === "success" && <span className="text-xl">✔️</span>}
              {alert.type === "error" && <span className="text-xl">❌</span>}
              {alert.type === "warning" && <span className="text-xl">⚠️</span>}
              <p>{alert.message}</p>
            </div>
          )}
        </div>

        {/* SUCCESS MODAL */}
        {showSuccessModal && (
          <div className="fixed inset-0 flex items-center justify-center backdrop-blur-md bg-black/20 z-50">
            <div className="bg-white rounded-xl p-8 w-[90%] max-w-md text-center shadow-xl animate-fadeIn">
              <div className="flex justify-center mb-4">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 text-5xl">✔</span>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Registration Successful!
              </h2>

              <p className="text-gray-600 mb-6">
                Your professor account has been created successfully. You can now log in.
              </p>

              <button
                onClick={() => {
                  setShowSuccessModal(false);
                  router.push("/professor/login");
                }}
                className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
              >
                Continue to Login
              </button>
            </div>
          </div>
        )}

        {/* SCROLLABLE FORM CONTAINER */}
        <div className="bg-white shadow-lg rounded-2xl p-8 w-full max-w-md h-[80vh] overflow-y-auto">
          <form
            onSubmit={otpSent ? verifyOtp : sendOtp}
            className="space-y-6"
          >
            {/* Full Name */}
            <div>
              <label className="block font-medium mb-1 text-gray-700">Full Name</label>
              <input
                name="name"
                type="text"
                value={form.name}
                onChange={handleChange}
                placeholder="Enter full name"
                className="w-full border rounded-lg px-3 py-2"
                required
              />
            </div>

            {/* Department */}
            <div>
              <label className="block font-medium mb-1 text-gray-700">Department</label>
              <input
                name="department"
                type="text"
                value={form.department}
                onChange={handleChange}
                placeholder="Enter department"
                className="w-full border rounded-lg px-3 py-2"
                required
              />
            </div>

            {/* Bio */}
            <div>
              <label className="block font-medium mb-1 text-gray-700">Bio</label>
              <input
                name="bio"
                type="text"
                value={form.bio}
                onChange={handleChange}
                placeholder="Short bio"
                className="w-full border rounded-lg px-3 py-2"
                required
              />
            </div>

            {/* Specialization */}
            <div>
              <label className="block font-medium mb-1 text-gray-700">Specialization</label>
              <input
                name="specialization"
                type="text"
                value={form.specialization}
                onChange={handleChange}
                placeholder="Enter specialization"
                className="w-full border rounded-lg px-3 py-2"
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="block font-medium mb-1 text-gray-700">Password</label>
              <input
                name="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                placeholder="Enter password"
                className="w-full border rounded-lg px-3 py-2"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block font-medium mb-1 text-gray-700">Email</label>
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="Enter email"
                className="w-full border rounded-lg px-3 py-2"
                required
              />
            </div>

            {/* Buttons */}
            {!otpSent ? (
              <button
                type="submit"
                className="w-full bg-indigo-600 text-white py-2 rounded-lg"
              >
                {sendLoading ? "Sending..." : "Send OTP"}
              </button>
            ) : (
              <div className="space-y-4">
                {/* OTP Input */}
                <div>
                  <label className="block font-medium mb-1 text-gray-700">
                    Enter OTP
                  </label>
                  <input
                    name="otp"
                    type="text"
                    value={form.otp}
                    onChange={handleChange}
                    placeholder="Enter OTP received on email"
                    className="w-full border rounded-lg px-3 py-2"
                    required
                  />
                </div>

                {/* Validate OTP */}
                <button
                  type="submit"
                  className="w-full bg-green-600 text-white py-2 rounded-lg"
                >
                  {verifyLoading
                    ? "Validating..."
                    : "Validate OTP & Complete Registration"}
                </button>

                {/* Resend OTP */}
                <button
                  type="button"
                  onClick={sendOtp}
                  className="w-full bg-indigo-500 text-white py-2 rounded-lg"
                >
                  {sendLoading ? "Sending… ⏳" : "Resend OTP"}
                </button>
              </div>
            )}
          </form>
        </div>
      </main>
    </div>
  );
}
