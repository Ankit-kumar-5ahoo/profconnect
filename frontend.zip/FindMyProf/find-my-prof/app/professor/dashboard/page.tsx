"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";

/**
 * Professor Dashboard (LocalStorage-backed)
 *
 * - Stores opportunities in localStorage under "opportunities"
 * - PDF files are stored as Base64 strings (pdfBase64) with pdfName
 * - Seeds demo data once if no opportunities exist
 * - Filters by institute and by "recently added"
 * - Delete, Edit PDF (replace), View PDF (open new tab)
 */

/* --------------------
   Types
   -------------------- */
interface Opportunity {
  id: number;
  title: string;
  description?: string;
  professor?: string;
  professorId?: number;
  institute?: string;
  field?: string;
  type?: string;
  duration?: string;
  prerequisites?: string;
  pdfBase64?: string; // Base64 string of PDF
  pdfName?: string; // filename
  pdfUrl?: string;
  createdAt: number; // timestamp
}

/* --------------------
   Helpers
   -------------------- */

// Get current professor id from session storage token like "prof_123"
const getCurrentProfessorId = (): number | null => {
  try {
    const token = sessionStorage.getItem("professor_token");
    if (!token) return null;
    const parts = token.split("_");
    const id = Number(parts[1]);
    return Number.isFinite(id) ? id : null;
  } catch {
    return null;
  }
};

// read opportunities from localStorage
const readOpportunitiesFromStorage = (): Opportunity[] => {
  try {
    const raw = localStorage.getItem("opportunities");
    if (!raw) return [];
    return JSON.parse(raw) as Opportunity[];
  } catch {
    return [];
  }
};

// write opportunities to localStorage
const writeOpportunitiesToStorage = (arr: Opportunity[]) => {
  localStorage.setItem("opportunities", JSON.stringify(arr));
};

// convert File -> Base64 (returns Promise<string>)
const fileToBase64 = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1] ?? result); // return only base64 part if data URL
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });

// create Blob URL and open new tab from base64 pdf
const openPdfBase64InNewTab = (base64: string, filename = "file.pdf") => {
  try {
    // convert base64 to bytes
    const byteChars = atob(base64);
    const byteNumbers = new Array(byteChars.length);
    for (let i = 0; i < byteChars.length; i++) {
      byteNumbers[i] = byteChars.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank")?.focus();

    // revoke URL after short time (browser may keep it for next tab)
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  } catch (e) {
    console.error("Failed to open PDF", e);
  }
};

/* --------------------
   Component
   -------------------- */
function ProfessorDashboard() {
  const router = useRouter();

  // data state
  const [authChecking, setAuthChecking] = useState(true);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);
  const [pdfSizeError, setPdfSizeError] = useState("");
  const MAX_PDF_SIZE = 300 * 1024; // 300 KB

  // UI state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedOppId, setSelectedOppId] = useState<number | null>(null);
  const [newPdfFile, setNewPdfFile] = useState<File | null>(null);

  // filters
  const [instituteFilter, setInstituteFilter] = useState<string>("All");
  const [sortRecentlyAdded, setSortRecentlyAdded] = useState<boolean>(false);

  // alerts & toasts
  const [alert, setAlert] = useState({
    type: "" as "success" | "error" | "warning" | "",
    message: "",
    show: false,
  });

  const showAlert = (
    type: "success" | "error" | "warning" | "",
    message: string
  ) => {
    setAlert({ type, message, show: true });
    setTimeout(() => setAlert({ type: "", message: "", show: false }), 3000);
  };

  // modal for success actions (reused)
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successModalMsg, setSuccessModalMsg] = useState("");
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [oppToDelete, setOppToDelete] = useState<Opportunity | null>(null);

  useEffect(() => {
    const token = sessionStorage.getItem("professor_token");
    if (!token) {
      router.replace("/professor/login"); 
      return;
    }
    setAuthChecking(false);
    fetchOpportunities();
  }, []);

  // fetch from localStorage and apply professor filter
  const fetchOpportunities = () => {
    setLoading(true);
    const all = readOpportunitiesFromStorage();
    setOpportunities(all);
    setLoading(false);
  };

  // list of institutes for filter options
  const instituteOptions = Array.from(
    new Set(
      readOpportunitiesFromStorage()
        .map((o) => o.institute || "")
        .filter(Boolean)
    )
  );

  // apply UI filters & sorting before rendering
  const displayedOpportunities = React.useMemo(() => {
    let list = [...opportunities];

    if (instituteFilter && instituteFilter !== "All") {
      list = list.filter(
        (o) =>
          (o.institute || "").toLowerCase() === instituteFilter.toLowerCase()
      );
    }

    if (sortRecentlyAdded) {
      list.sort((a, b) => b.createdAt - a.createdAt);
    }

    return list;
  }, [opportunities, instituteFilter, sortRecentlyAdded]);

  /* --------------------
     CRUD actions
     -------------------- */

  // Delete opportunity (localStorage)
  const promptDeleteOpportunity = (opp: Opportunity) => {
    setOppToDelete(opp);
    setDeleteModalOpen(true);
  };

  const confirmDeleteOpportunity = () => {
    if (!oppToDelete) return;
    try {
      const all = readOpportunitiesFromStorage();
      const updated = all.filter((o) => o.id !== oppToDelete.id);
      writeOpportunitiesToStorage(updated);
      showAlert("success", "Opportunity deleted successfully");
      setDeleteModalOpen(false);
      setOppToDelete(null);
      fetchOpportunities();
    } catch (e) {
      console.error("Delete error:", e);
      showAlert("error", "Failed to delete opportunity");
    }
  };

  const cancelDelete = () => {
    setDeleteModalOpen(false);
    setOppToDelete(null);
  };

  // Open edit modal
  const openEditModal = (id: number) => {
    setSelectedOppId(id);
    setNewPdfFile(null);
    setEditModalOpen(true);
  };

  // Update PDF for selected opportunity
  const updatePdf = async () => {
    if (!selectedOppId) {
      showAlert("error", "No opportunity selected");
      return;
    }
    if (!newPdfFile) {
      showAlert("error", "Please pick a PDF file to upload");
      return;
    }

    // validate file type
    if (newPdfFile.type !== "application/pdf") {
      showAlert("error", "Only PDF files are allowed");
      return;
    }

    if (pdfSizeError) {
      showAlert("error", pdfSizeError);
      return;
    }

    if (newPdfFile.size > MAX_PDF_SIZE) {
      showAlert("error", "PDF size exceeds 300 KB limit");
      return;
    }

    try {
      const base64 = await fileToBase64(newPdfFile);

      const all = readOpportunitiesFromStorage();
      const idx = all.findIndex((o) => o.id === selectedOppId);
      if (idx === -1) {
        showAlert("error", "Opportunity not found");
        return;
      }

      all[idx] = {
        ...all[idx],
        pdfBase64: base64,
        pdfName: newPdfFile.name,
        pdfUrl: "",
      };
      // update createdAt? keep original createdAt, but record lastUpdated could be added
      writeOpportunitiesToStorage(all);

      showAlert("success", "PDF updated successfully");
      setEditModalOpen(false);
      fetchOpportunities();
    } catch (e) {
      console.error("PDF update error:", e);
      showAlert("error", "Failed to update PDF");
    }
  };

  // View PDF
  const viewPdf = (o: Opportunity) => {
    if (o.pdfBase64) {
      openPdfBase64InNewTab(o.pdfBase64, o.pdfName || "file.pdf");
      return;
    }

    if (o.pdfUrl) {
      window.open(o.pdfUrl, "_blank");
      return;
    }

    showAlert("warning", "No PDF available");
  };


  return authChecking ? (
    <div className="min-h-screen flex items-center justify-center text-gray-600">
      Redirecting…
    </div>
  ) : (
    <div className="min-h-screen bg-gradient-to-r from-blue-50 to-indigo-50">
      {/* Top Nav */}

      <nav className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 shadow-md flex justify-between items-center">
        <h1 className="text-xl font-bold">ProfConnect</h1>

        <div className="flex gap-3">
          <button
            onClick={() => (window.location.href = "/")}
            className="bg-white text-indigo-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition"
          >
            Home
          </button>

          <button
            onClick={() => {
              sessionStorage.removeItem("professor_token");
              window.location.href = "/";
            }}
            className="bg-white text-indigo-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition"
          >
            Logout
          </button>
        </div>
      </nav>

      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-5 shadow-md">
        <h1 className="text-2xl font-bold">Professor Dashboard</h1>
      </header>

      {/* Controls */}
      <section className="p-6 flex flex-col md:flex-row md:items-center md:gap-4 gap-3">
        <a
          href="/professor/post-opportunity"
          className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-2xl shadow-md transition inline-block"
        >
          Post New Opportunity
        </a>

        <div className="flex gap-3 items-center">
          <label className="font-medium text-gray-700">Institute:</label>
          <select
            value={instituteFilter}
            onChange={(e) => setInstituteFilter(e.target.value)}
            className="border rounded-lg px-3 py-2 focus:ring focus:ring-blue-200"
          >
            <option value="All">All</option>
            {instituteOptions.map((inst) => (
              <option key={inst} value={inst}>
                {inst}
              </option>
            ))}
          </select>

          <label className="flex items-center gap-2 ml-2">
            <input
              type="checkbox"
              checked={sortRecentlyAdded}
              onChange={(e) => setSortRecentlyAdded(e.target.checked)}
              className="h-4 w-4"
            />
            <span className="text-gray-700">Recently Added</span>
          </label>
        </div>
      </section>

      {/* Opportunities Grid */}
      <main className="p-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {loading && <p>Loading...</p>}

        {!loading && displayedOpportunities.length === 0 && (
          <div className="col-span-full bg-white p-6 rounded-2xl shadow text-center">
            <p className="text-gray-600">No opportunities found.</p>
          </div>
        )}

        {!loading &&
          displayedOpportunities.map((opp) => (
            <div
              key={opp.id}
              className="opportunity-card bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition flex flex-col"
            >
              <h2 className="text-xl font-bold text-indigo-700 mb-2">
                {opp.title}
              </h2>

              <p className="text-gray-600 mb-1">
                <strong>Professor:</strong> {opp.professor || "—"}
              </p>

              <p className="text-gray-600 mb-1">
                <strong>Institute:</strong> {opp.institute || "—"}
              </p>

              <p className="text-gray-600 mb-1">
                <strong>Field:</strong> {opp.field || "—"}
              </p>

              <p className="text-gray-600 mb-1">
                <strong>Type:</strong> {opp.type || "—"}
              </p>

              <p className="text-gray-600 mb-1">
                <strong>Duration:</strong> {opp.duration || "—"}
              </p>

              <p className="text-gray-600 mb-3">
                <strong>Pre-requisites:</strong> {opp.prerequisites || "—"}
              </p>

              <div className="flex gap-2 mt-auto">
                <button
                  onClick={() => viewPdf(opp)}
                  className="text-blue-600 hover:underline text-sm"
                >
                  View PDF Details
                </button>

                <button
                  className="edit-btn bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg px-4 py-2 transition"
                  onClick={() => openEditModal(opp.id)}
                >
                  Edit PDF
                </button>

                <button
                  className="delete-btn bg-red-500 hover:bg-red-600 text-white rounded-lg px-4 py-2 transition"
                  onClick={() => promptDeleteOpportunity(opp)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
      </main>

      {/* Edit PDF Modal */}
      {editModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center backdrop-blur-md bg-black/30 z-50">
          <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-lg">
            <h2 className="text-xl font-bold mb-3">Replace PDF</h2>

            <p className="text-gray-600 mb-4">
              Choose a new PDF to replace the current one.
            </p>

            <input
              type="file"
              accept="application/pdf"
              className="w-full border rounded-lg px-3 py-2 mb-2 cursor-pointer file:border file:border-gray-400 file:px-3 file:py-1"
              onChange={(e) => {
                const file = e.target.files?.[0] || null;

                setPdfSizeError("");
                setNewPdfFile(file);

                if (!file) return;

                // File size validation
                if (file.size > MAX_PDF_SIZE) {
                  setPdfSizeError(
                    `File too large (${(file.size / 1024).toFixed(
                      1
                    )} KB). Max allowed is 300 KB.`
                  );
                }
              }}
            />

            {newPdfFile && (
              <p className="text-sm text-gray-600 mb-1">
                Selected File: <strong>{newPdfFile.name}</strong> (
                {(newPdfFile.size / 1024).toFixed(1)} KB)
              </p>
            )}

            {pdfSizeError && (
              <p className="text-sm text-red-600 font-medium mb-3">
                ⚠ {pdfSizeError}
              </p>
            )}

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setEditModalOpen(false);
                  setSelectedOppId(null);
                }}
                className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300"
              >
                Cancel
              </button>

              <button
                onClick={updatePdf}
                disabled={!!pdfSizeError || !newPdfFile}
                className={`px-4 py-2 rounded-lg text-white transition ${
                  pdfSizeError || !newPdfFile
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-indigo-600 hover:bg-indigo-700"
                }`}
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE OPPORTUNITY MODAL */}
      {deleteModalOpen && oppToDelete && (
        <div className="fixed inset-0 flex items-center justify-center backdrop-blur-md bg-black/30 z-50">
          <div className="bg-white rounded-2xl shadow-2xl p-6 w-[90%] max-w-md text-center">
            <div className="w-20 h-20 bg-red-100 rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-4xl text-red-600">⚠️</span>
            </div>

            <h2 className="text-xl font-bold text-gray-800 mb-2">
              Are you sure you want to delete this opportunity?
            </h2>

            <p className="text-gray-600 mb-6">This action cannot be undone.</p>

            <div className="flex justify-end gap-3">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg"
              >
                Cancel
              </button>

              <button
                onClick={confirmDeleteOpportunity}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ALERT BOX */}
      <div className="fixed top-6 left-1/2 transform -translate-x-1/2 w-full max-w-lg z-50 pointer-events-none">
        {alert.show && (
          <div
            className={`mx-auto pointer-events-auto p-3 rounded-lg flex items-center gap-2 text-white shadow-md
              ${
                alert.type === "success"
                  ? "bg-green-600"
                  : alert.type === "error"
                  ? "bg-red-600"
                  : "bg-yellow-500"
              }
            `}
          >
            {alert.type === "success" && <span className="text-xl">✔️</span>}
            {alert.type === "error" && <span className="text-xl">❌</span>}
            {alert.type === "warning" && <span className="text-xl">⚠️</span>}
            <p className="font-medium">{alert.message}</p>
          </div>
        )}
      </div>

      {/* Optional global success modal (e.g., for redirects) */}
      {showSuccessModal && (
        <div className="fixed inset-0 flex items-center justify-center backdrop-blur-md bg-black/30 z-60">
          <div className="bg-white rounded-xl p-6 w-[90%] max-w-md text-center shadow-xl">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-green-600 text-4xl">✔</span>
            </div>
            <h3 className="text-xl font-semibold mb-2">Success</h3>
            <p className="text-gray-600 mb-4">{successModalMsg || "Done"}</p>
            <div className="flex justify-center">
              <button
                onClick={() => setShowSuccessModal(false)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default dynamic(() => Promise.resolve(ProfessorDashboard), {
  ssr: false,
});
