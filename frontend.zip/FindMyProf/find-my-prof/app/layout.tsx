"use client";

import { useEffect } from "react";
import "./globals.css";
import { seedOpportunities, seedProfessors, seedStudents } from "./utils/seedData";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  useEffect(() => {
    seedOpportunities();
    seedProfessors();
    seedStudents();
  }, []);

  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
