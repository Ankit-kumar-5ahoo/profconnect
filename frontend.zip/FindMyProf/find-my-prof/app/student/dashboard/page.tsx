"use client";

import { useEffect, useState } from "react";

interface Opportunity {
  id: number;
  title: string;
  description?: string;
  professor?: string;
  professorId?: number;
  professorEmail?: string;
  institute?: string;
  field?: string;
  type?: string;
  duration?: string;
  prerequisites?: string;
  pdfBase64?: string;
  pdfName?: string;
  pdfUrl?: string;
  createdAt: number;
}

export default function StudentDashboard() {
  const [authChecking, setAuthChecking] = useState(true);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);

  // Email Modal
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [profEmail, setProfEmail] = useState("");

  // Filters
  const [instituteFilter, setInstituteFilter] = useState("All");

  // ----------------------------------
  // 🔐 AUTH CHECK
  // ----------------------------------
  useEffect(() => {
    const token = sessionStorage.getItem("student_token");
    if (!token) {
      window.location.href = "/student/login";
      return;
    }

    loadOpportunities();
    setAuthChecking(false);
  }, []);

  // ----------------------------------
  // 📌 Load opportunities
  // ----------------------------------
  const loadOpportunities = () => {
    const raw = localStorage.getItem("opportunities");
    if (!raw) return;
    setOpportunities(JSON.parse(raw));
  };

  // ----------------------------------
  // 📌 Unique Institutes for filter
  // ----------------------------------
  const instituteOptions = Array.from(
    new Set(opportunities.map((o) => o.institute).filter(Boolean))
  );

  // ----------------------------------
  // 📌 Filtered List
  // ----------------------------------
  const filteredOpportunities = opportunities.filter((opp) =>
    instituteFilter === "All"
      ? true
      : opp.institute?.toLowerCase() === instituteFilter.toLowerCase()
  );

  // ----------------------------------
  // 📄 View PDF
  // ----------------------------------
  const openPdf = (opp: Opportunity) => {
    if (opp.pdfBase64) {
      const byteChars = atob(opp.pdfBase64);
      const bytes = new Uint8Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++)
        bytes[i] = byteChars.charCodeAt(i);

      const blob = new Blob([bytes], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
      return;
    }

    if (opp.pdfUrl) {
      window.open(opp.pdfUrl, "_blank");
      return;
    }

    alert("No PDF uploaded for this opportunity.");
  };

  const openEmailModal = (email: string) => {
    setProfEmail(email);
    setShowEmailModal(true);
  };

  if (authChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-600">
        Redirecting…
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen flex flex-col">
      {/* Sticky Header: includes nav + title row */}
      <header className="sticky top-0 z-50">
        <div
          className="w-full"
          style={{
            // gradient closer to screenshot: left-blue -> right-purple
            background:
              "linear-gradient(90deg,#2f6ef1 0%, #6c3cf0 45%, #5b3bf0 100%)",
          }}
        >
          <div className="max-w-[1400px] mx-auto px-6">
            <div className="flex items-center justify-between py-4">
              <div className="text-white flex items-center gap-4">
                <h1 className="text-lg font-bold">ProfConnect</h1>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => (window.location.href = "/")}
                  className="bg-white text-indigo-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition"
                  aria-label="Home"
                >
                  Home
                </button>

                <button
                  onClick={() => {
                    sessionStorage.removeItem("professor_token");
                    sessionStorage.removeItem("professor_email");
                    sessionStorage.removeItem("professor_name");
                    window.location.href = "/";
                  }}
                  className="bg-white text-indigo-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition"
                  aria-label="Logout"
                >
                  Logout
                </button>
              </div>
            </div>

            {/* Title / subtitle row */}
            <div className="py-4 pb-6">
              <h2 className="text-white text-2xl font-bold">
                ProfConnect - Student Dashboard
              </h2>
            </div>
          </div>
        </div>
      </header>

      {/* Course Recommendation Button */}
      <div className="max-w-[1400px] mx-auto px-6 pt-6 flex justify-start">
        <a
          href="https://course-recommender-system-rust.vercel.app/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-purple-600 hover:bg-purple-700 text-white font-semibold px-6 py-3 rounded-2xl shadow-lg transition"
          aria-label="Course Recommendation System"
        >
          Course Recommendation System
        </a>
      </div>

      {/* Filter */}
      <section className="bg-white shadow-md p-6 sticky top-0 z-10 flex items-center gap-4">
        <label className="font-medium text-gray-700">
          Filter by Institute:
        </label>

        <select
          value={instituteFilter}
          onChange={(e) => setInstituteFilter(e.target.value)}
          className="border rounded-lg px-3 py-2 focus:ring focus:ring-indigo-200"
        >
          <option value="All">All</option>

          {instituteOptions.map((inst) => (
            <option key={inst} value={inst}>
              {inst}
            </option>
          ))}
        </select>
      </section>

      {/* Opportunities Grid */}
      <main className="p-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredOpportunities.length === 0 && (
          <p className="text-gray-600 col-span-full text-center">
            No opportunities found.
          </p>
        )}

        {filteredOpportunities.map((opp) => (
          <div
            key={opp.id}
            className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition flex flex-col"
          >
            <h2 className="text-xl font-bold text-green-700 mb-2">
              {opp.type || "Opportunity"}
            </h2>

            <p className="text-gray-600 mb-1">
              <strong>Professor:</strong> {opp.professor}
            </p>

            <p className="text-gray-600 mb-1">
              <strong>Institute:</strong> {opp.institute}
            </p>

            <p className="text-gray-600 mb-1">
              <strong>Field:</strong> {opp.field}
            </p>

            <p className="text-gray-600 mb-1">
              <strong>Duration:</strong> {opp.duration}
            </p>

            <p className="text-gray-600 mb-3">
              <strong>Pre-requisites:</strong> {opp.prerequisites}
            </p>

            <button
              onClick={() => openPdf(opp)}
              className="text-indigo-600 hover:underline text-sm mb-3 block text-left"
            >
              View PDF Details
            </button>

            <button
              onClick={() => {
                const mailto = `https://mail.google.com/mail/?view=cm&fs=1&to=${opp.professorEmail}&su=Application for Opportunity&body=Dear Professor,%0D%0A%0D%0AI am interested in applying for ${opp.title} opportunity.%0D%0A%0D%0AThanks`;
                window.open(mailto, "_blank");
              }}
              className="mt-auto bg-green-600 hover:bg-green-700 text-white rounded-lg px-4 py-2 transition"
            >
              Apply
            </button>
          </div>
        ))}
      </main>

      {/* EMAIL POPUP MODAL */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-md relative">
            {/* Close Button */}
            <button
              onClick={() => setShowEmailModal(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
            >
              ✖
            </button>

            <h2 className="text-xl font-bold mb-4 text-indigo-700">
              Send Email
            </h2>

            <label className="block font-medium text-gray-700">To:</label>
            <input
              type="email"
              value={profEmail}
              readOnly
              className="w-full border rounded-lg px-3 py-2 mb-4 bg-gray-100"
            />

            <label className="block font-medium text-gray-700">Subject</label>
            <input
              type="text"
              placeholder="Write subject..."
              className="w-full border rounded-lg px-3 py-2 mb-4"
            />

            <label className="block font-medium text-gray-700">Message</label>
            <textarea
              rows={4}
              placeholder="Write your message..."
              className="w-full border rounded-lg px-3 py-2 mb-4"
            ></textarea>

            <button
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg transition"
              onClick={() => {
                alert("Email Sent Successfully!");
                setShowEmailModal(false);
              }}
            >
              Send Email
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
