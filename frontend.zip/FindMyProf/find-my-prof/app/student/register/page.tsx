"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";

export default function StudentRegister() {
  const router = useRouter();

  const [form, setForm] = useState({
    name: "",
    email: "",
    department: "",
    year: "",
    password: "",
    otp: "",
  });

  const [otpSent, setOtpSent] = useState(false);
  const [sendLoading, setSendLoading] = useState(false);
  const [verifyLoading, setVerifyLoading] = useState(false);
  const [emailError, setEmailError] = useState("");

  const [alert, setAlert] = useState({
    type: "", // success | error | warning
    message: "",
    show: false,
  });

  const showAlert = (type: string, message: string) => {
    setAlert({ type, message, show: true });

    // Auto hide after 3 seconds
    setTimeout(() => {
      setAlert({ type: "", message: "", show: false });
    }, 3000);
  };

  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;

    // Email validation (field-level)
    if (name === "email") {
      const domain = value.split("@")[1];

      if (value && (!domain || !allowedDomains.includes(domain))) {
        setEmailError(
          "Email must belong to one of these domains: iitb.ac.in, pilani.bits-pilani.ac.in, iitkgp.ac.in"
        );
      } else {
        setEmailError("");
      }
    }

    setForm({ ...form, [name]: value });
  };

  // Save student to LocalStorage
  const saveStudentToLocal = (student: any) => {
    const existing = JSON.parse(localStorage.getItem("students") || "[]");

    if (existing.some((s: any) => s.email === student.email)) {
      return { ok: false, message: "Email already registered!" };
    }

    existing.push({ id: Date.now(), ...student });
    localStorage.setItem("students", JSON.stringify(existing));
    return { ok: true };
  };

  // SEND OTP
  const sendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (emailError) {
      showAlert(
        "error",
        "Please enter a valid institute email before proceeding."
      );
      return;
    }
    setSendLoading(true);

    try {
      await fetch("/api/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email }),
      });

      setOtpSent(true);
      showAlert("success", "OTP sent to your email!");
    } catch (error) {
      console.error("OTP Error:", error);
      showAlert("error", "Failed to send OTP. Try again.");
    }

    setSendLoading(false);
  };

  // VERIFY OTP + REGISTER
  const verifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setVerifyLoading(true);

    try {
      // OTP verification API (UNCHANGED)
      const res = await fetch("/api/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email, otp: form.otp }),
      });

      const data = await res.json();

      if (!data.success) {
        showAlert("error", "Invalid OTP. Please try again.");
        setVerifyLoading(false);
        return;
      }

      // Store student in LocalStorage
      const result = saveStudentToLocal({
        name: form.name,
        email: form.email,
        department: form.department,
        year: form.year,
        password: form.password,
      });

      if (!result.ok) {
        showAlert("warning", result.message ?? "Unknown error");
        setVerifyLoading(false);
        return;
      }

      setShowSuccessModal(true);
    } catch (error) {
      console.error("Verification Error:", error);
      showAlert("error", "Something went wrong. Try again.");
    }

    setVerifyLoading(false);
  };

  const allowedDomains = [
    "iitb.ac.in",
    "pilani.bits-pilani.ac.in",
    "iitkgp.ac.in",
  ];

  return (
    <div className="bg-gradient-to-r from-indigo-50 to-blue-50 min-h-screen flex flex-col">
      <header className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white text-center py-4 shadow-md">
        <h1 className="text-2xl font-bold">Student Registration</h1>
      </header>

      <main className="flex-grow flex items-center justify-center p-6">
        {/* ALERT BOX */}
        <div className="absolute top-24 w-full max-w-md mx-auto">
          {alert.show && (
            <div
              className={`p-3 rounded-lg flex items-center gap-2 text-white shadow-md animate-fadeIn
                ${
                  alert.type === "success"
                    ? "bg-green-600"
                    : alert.type === "error"
                    ? "bg-red-600"
                    : "bg-yellow-500"
                }
              `}
            >
              {/* ICONS */}
              {alert.type === "success" && <span className="text-xl">✔️</span>}
              {alert.type === "error" && <span className="text-xl">❌</span>}
              {alert.type === "warning" && <span className="text-xl">⚠️</span>}

              <p className="font-medium">{alert.message}</p>
            </div>
          )}
        </div>

        {showSuccessModal && (
          <div className="fixed inset-0 flex items-center justify-center backdrop-blur-sm bg-black/30 z-50">
            <div className="bg-white rounded-xl p-8 w-[90%] max-w-md text-center shadow-xl animate-fadeIn">
              <div className="flex justify-center mb-4">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 text-5xl">✔</span>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Registration Successful!
              </h2>

              <p className="text-gray-600 mb-6">
                Your account has been created successfully. You can now log in.
              </p>

              <button
                onClick={() => {
                  setShowSuccessModal(false);
                  router.push("/student/login");
                }}
                className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
              >
                Continue to Login
              </button>
            </div>
          </div>
        )}

        <form
          onSubmit={otpSent ? verifyOtp : sendOtp}
          className="bg-white shadow-lg rounded-2xl p-8 w-full max-w-md space-y-6"
        >
          {/* Name */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Full Name
            </label>
            <input
              name="name"
              type="text"
              value={form.name}
              onChange={handleChange}
              placeholder="Enter full name"
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Email */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Email
            </label>

            <input
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Enter email"
              className={`w-full border rounded-lg px-3 py-2 ${
                emailError ? "border-red-500" : ""
              }`}
              required
            />

            {emailError && (
              <p className="text-red-600 text-sm mt-1">{emailError}</p>
            )}
          </div>

          {/* Department */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Department
            </label>
            <input
              name="department"
              type="text"
              value={form.department}
              onChange={handleChange}
              placeholder="Enter department"
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Year */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Academic Year
            </label>
            <input
              name="year"
              type="text"
              value={form.year}
              onChange={handleChange}
              placeholder="e.g. 1st Year"
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="block font-medium mb-1 text-gray-700">
              Password
            </label>
            <input
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              placeholder="Enter password"
              className="w-full border rounded-lg px-3 py-2"
              required
            />
          </div>

          {/* Buttons */}
          {!otpSent ? (
            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-2 rounded-lg"
            >
              {sendLoading ? "Sending..." : "Send OTP"}
            </button>
          ) : (
            <div className="space-y-4">
              {/* OTP Input */}
              <div>
                <label className="block font-medium mb-1 text-gray-700">
                  Enter OTP
                </label>
                <input
                  name="otp"
                  type="text"
                  value={form.otp}
                  onChange={handleChange}
                  placeholder="Enter OTP received"
                  className="w-full border rounded-lg px-3 py-2"
                  required
                />
              </div>

              {/* Validate OTP */}
              <button
                type="submit"
                className="w-full bg-green-600 text-white py-2 rounded-lg"
              >
                {verifyLoading
                  ? "Validating..."
                  : "Validate OTP & Complete Registration"}
              </button>

              {/* Resend OTP */}
              <button
                type="button"
                onClick={sendOtp}
                className="w-full bg-indigo-500 text-white py-2 rounded-lg"
              >
                {sendLoading ? "Sending… ⏳" : "Resend OTP"}
              </button>
            </div>
          )}
        </form>
      </main>
    </div>
  );
}
