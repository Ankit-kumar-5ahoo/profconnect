"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function StudentLogin() {
  const router = useRouter();

  // ---------------------
  // FORM STATE
  // ---------------------
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  // ---------------------
  // ALERT STATE
  // ---------------------
  const [alert, setAlert] = useState({
    type: "",
    message: "",
    show: false,
  });

  const showAlert = (type: string, message: string) => {
    setAlert({ type, message, show: true });

    setTimeout(() => {
      setAlert({ type: "", message: "", show: false });
    }, 2500);
  };

  // ---------------------
  // SUCCESS MODAL
  // ---------------------
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // ---------------------
  // LOCAL LOGIN LOGIC
  // ---------------------
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Read student accounts
    const students = JSON.parse(localStorage.getItem("students") || "[]");

    // Match email + password
    const student = students.find(
      (s: any) => s.email === email && s.password === password
    );

    if (!student) {
      showAlert("error", "Invalid email or password");
      setLoading(false);
      return;
    }

    // Save token
    sessionStorage.setItem("student_token", `stud_${student.id}`);

    // Show success modal
    setShowSuccessModal(true);

    setLoading(false);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-blue-50 to-indigo-50 p-4 relative">

      {/* ALERT BOX */}
      <div className="absolute top-10 w-full max-w-md mx-auto">
        {alert.show && (
          <div
            className={`p-3 rounded-lg flex items-center gap-2 text-white shadow-md animate-fadeIn
              ${
                alert.type === "success"
                  ? "bg-green-600"
                  : alert.type === "error"
                  ? "bg-red-600"
                  : "bg-yellow-500"
              }
            `}
          >
            {alert.type === "success" && <span className="text-xl">✔️</span>}
            {alert.type === "error" && <span className="text-xl">❌</span>}
            {alert.type === "warning" && <span className="text-xl">⚠️</span>}
            <p>{alert.message}</p>
          </div>
        )}
      </div>

      {/* SUCCESS MODAL */}
      {showSuccessModal && (
        <div className="fixed inset-0 flex items-center justify-center backdrop-blur-md bg-black/20 z-50">
          <div className="bg-white rounded-xl p-8 w-[90%] max-w-md text-center shadow-xl animate-fadeIn">
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                <span className="text-green-600 text-5xl">✔</span>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-gray-800 mb-2">
              Login Successful!
            </h2>

            <p className="text-gray-600 mb-6">
              Welcome back, Student. Redirecting to your dashboard…
            </p>

            <button
              onClick={() => {
                setShowSuccessModal(false);
                router.push("/student/dashboard");
              }}
              className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
            >
              Continue
            </button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <h2 className="text-3xl font-bold text-center text-indigo-700 mb-6">
          Student Login
        </h2>

        <form className="space-y-4" onSubmit={handleLogin}>
          <input
            type="email"
            placeholder="Student Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
            required
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
            required
          />

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg py-2 transition"
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <p className="text-center text-sm text-gray-600 mt-4">
          Don’t have an account?{" "}
          <Link
            href="/student/register"
            className="text-indigo-600 hover:underline"
          >
            Register
          </Link>
        </p>

        <Link
          href="/"
          className="block text-center text-sm text-indigo-500 mt-3 hover:underline"
        >
          ← Back to Home
        </Link>
      </div>
    </div>
  );
}
